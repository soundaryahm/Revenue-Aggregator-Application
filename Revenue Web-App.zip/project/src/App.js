import React, { useState, useEffect } from 'react';
import './styles.css'; // Ensure CSS is imported

// Format number function
const formatNumber = (number) => {
  return new Intl.NumberFormat().format(number.toFixed(2));
};

const App = () => {
  const [products, setProducts] = useState([]);
  const [filter, setFilter] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const responses = await Promise.all([
          fetch('api/branch1.json'),
          fetch('api/branch2.json'),
          fetch('api/branch3.json'),
        ]);

        const data = await Promise.all(responses.map(response => response.json()));

        // Merging and processing data
        const mergedData = {};
        data.forEach(branch => {
          branch.products.forEach(product => {
            if (mergedData[product.name]) {
              mergedData[product.name] += product.unitPrice * product.sold;
            } else {
              mergedData[product.name] = product.unitPrice * product.sold;
            }
          });
        });

        // Convert mergedData object to array
        const processedData = Object.keys(mergedData).map(name => ({
          name,
          totalRevenue: mergedData[name],
        }));

        // Sort alphabetically by product name
        processedData.sort((a, b) => a.name.localeCompare(b.name));

        setProducts(processedData);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, []);

  // Filtered and sorted products
  const filteredProducts = products.filter(product =>
    product.name.toLowerCase().includes(filter.toLowerCase())
  );

  // Total revenue calculation
  const totalRevenue = filteredProducts.reduce((total, product) => total + product.totalRevenue, 0);

  return (
    <div className="container">
      <div className="filter">
        <label htmlFor="filter-input">Filter:</label>
        <input
          type="text"
          id="filter-input"
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
        />
      </div>
      <table>
        <thead>
          <tr>
            <th>Product Name</th>
            <th>Total Revenue</th>
          </tr>
        </thead>
        <tbody>
          {filteredProducts.map((product, index) => (
            <tr key={index}>
              <td>{product.name}</td>
              <td>{formatNumber(product.totalRevenue)}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="total-revenue">
        Total Revenue: {formatNumber(totalRevenue)}
      </div>
    </div>
  );
};

export default App;
