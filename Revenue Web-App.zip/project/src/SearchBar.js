import React from 'react';

const SearchBar = ({ value, onChange }) => (
  <div style={{ marginBottom: '20px' }}>
    <label htmlFor="search" style={{ marginRight: '10px' }}>Search:</label>
    <input
      type="text"
      id="search"
      value={value}
      onChange={onChange}
      placeholder="Filter by product name"
    />
  </div>
);

export default SearchBar;
