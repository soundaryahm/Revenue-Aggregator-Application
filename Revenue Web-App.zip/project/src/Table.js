import React from 'react';
import { formatNumber } from './utils'; // Assuming you have a formatNumber function

const Table = ({ data, totalRevenue }) => (
  <div>
    <table>
      <thead>
        <tr>
          <th>Product Name</th>
          <th>Total Revenue</th>
        </tr>
      </thead>
      <tbody>
        {data.map((item, index) => (
          <tr key={index}>
            <td>{item.name}</td>
            <td>{formatNumber(item.totalRevenue)}</td>
          </tr>
        ))}
      </tbody>
      <tfoot>
        <tr>
          <td><strong>Total Revenue:</strong></td>
          <td>{formatNumber(totalRevenue)}</td>
        </tr>
      </tfoot>
    </table>
  </div>
);

export default Table;
